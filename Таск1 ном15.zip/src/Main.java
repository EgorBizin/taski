package vsu.bizin.cs;

import vsu.bizin.commons.ConsoleReader;
import vsu.bizin.commons.Vector3DUtils;
import vsu.bizin.figures.Vector3D;

public class Task1 {
    public static void main(String[] args) {
        final Vector3DUtils vector3DUtils = new Vector3DUtils();
        Vector3D vector1 = readVector();
        Vector3D vector2 = readVector();

        System.out.println("Vector length: " + vector3DUtils.countLength(vector1));
        System.out.println("Cos between vectors: " + vector3DUtils.countCosine(vector1, vector2));
        System.out.println("Sum of vectors: " + vector3DUtils.countSum(vector1, vector2));
        System.out.println("Dif of vectors: " + vector3DUtils.countDiff(vector1, vector2));
        System.out.println("Scalar product: " + vector3DUtils.countScalarProduct(vector1, vector2));
        System.out.println("Test sum varargs: " + vector3DUtils.countSum(vector1, vector2, vector1, vector1, vector1));
        System.out.println("Test dif varargs: " + vector3DUtils.countDiff(vector2, vector2, vector2, vector2));
    }

    private static Vector3D readVector() {
        final ConsoleReader consoleReader = new ConsoleReader();
        System.out.println("Enter coordinates for vector, please");
        final double x = consoleReader.readDouble("Input X: ");
        final double y = consoleReader.readDouble("Input Y: ");
        final double z = consoleReader.readDouble("Input Z: ");
        return new Vector3D(x, y, z);
    }
}