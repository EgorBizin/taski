import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

    public static void main(String[] args) throws IOException {
        List<String> list = new List<>();

        String[] strings = {"0","1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13"};

        for (String string : strings) {
            list.addItem(string);
        }

        System.out.println("содержимое списка");
        System.out.println(list);

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        System.out.print("введите l");
        int l = Integer.parseInt(reader.readLine());
        System.out.print("введите m");
        int m = Integer.parseInt(reader.readLine());

        list.removeNodes(l, m);

        System.out.println("после удаления элементов c l по m:\n" + list.toString());
    }
}